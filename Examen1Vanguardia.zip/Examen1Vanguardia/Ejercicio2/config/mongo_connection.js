let mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Productosdb', { useNewUrlParser: true });

var Schema = mongoose.Schema;
autoIncrement = require('mongoose-auto-increment');
autoIncrement.initialize(mongoose);

var produtosSchema = new Schema({
    descripcion: String,
    marca: String,
    estante: String,
    sku: { type: String, unique: true }
}, { collection: 'productosdb' })

produtosSchema.plugin(autoIncrement.plugin, {
    model: 'productosdb',
    field: 'sku',
    startAt: 0,
    incrementBy: 1
});

var Datosproductos = mongoose.model('productosdb', produtosSchema);

module.exports = Datosproductos;