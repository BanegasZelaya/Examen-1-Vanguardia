var express = require('express');
var router = express.Router();
var mongo_conection = require('../config/mongo_connection');



router.post('/productos', function(req, res, next) {
    mongo_conection.create(req.body).then((value) => {
        res.send('Creado');
    });
});

router.get('/productos', function(req, res, next) {
    mongo_conection.find().then(value => {
        res.send(value)
    })
});

router.get('/productos/:sku', function(req, res, next) {
    let id = req.params.sku;
    mongo_conection.find({ 'sku': Number(id) }).then(value => {
        res.send(value)
    })
});

router.get('/productos/marca/:marca', function(req, res, next) {
    let marca = req.params.marca;
    mongo_conection.find({ 'marca': String(marca) }).then(value => {
        res.send(value)
    })
});

module.exports = router;