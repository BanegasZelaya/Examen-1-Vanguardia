const fs = require('fs')
const yargs = require('yargs')



const total = require('./Parametros/Parametros')

if (total) {
    fs.writeFile(`textos/ExamenParcial1.txt`, total, (err) => {
        if (err) throw err;
        console.log(`El archivo a sido creado con exito!`);
    })
};