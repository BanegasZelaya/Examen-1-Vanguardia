const yargs = require('yargs')
const _ = require('lodash')


function grab(flag) {
    var index = process.argv.indexOf(flag);
    return (index === -1) ? null : process.argv[index + 1]
}

var nombreclase = grab('--nombreclase');
var seccion = grab('--seccion');
var cuenta = grab('--cuenta');

if (!nombreclase || !seccion || !cuenta) {
    console.log('Datos incompletos, favor enviar todos los datos');
} else {

    var mensaje = 'Primer examen de vanguardia\n\n\n'
    var cuenta = `Numero de cuenta: ${cuenta}` + '\n'
    var clase = `Nombre de Clase: ${nombreclase}    seccion: ${seccion}` + '\n'

    var total = mensaje + cuenta + clase
}

module.exports = total;